import React from "react";
import q from'./Head.module.css';

const Head =() =>{

    return(
      <header className='head'>
      <h1 className={q.Name}>Site of men</h1>
      </header>
    );
}
export default Head;