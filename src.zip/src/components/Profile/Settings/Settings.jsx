import React from "react";
import q from'./Settings.module.css';

const Settings =() =>{

    return(
        
<div className='main'>
      its my Settings
       </div> 

    );
}
export default Settings;