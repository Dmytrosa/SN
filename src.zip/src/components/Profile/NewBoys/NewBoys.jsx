import React from "react";
import q from'./NewBoys.module.css';

const NewBoys =() =>{

    return(
        
<div className='main'>
      its my NewBoys
      
       </div> 

    );
}
export default NewBoys;