import React from "react";

const Chatinfo = () => {
    let chatsinfo =[
        { id: 0, name: 'Alina'},
         { id: 1, name: 'Natalia' },
             { id: 2, name: 'Sashko' },
                 { id: 3, name: 'Denis'  },
                 { id: 4, name: 'Chhi'  },
                 { id: 5, name: 'Chhi'  },   
 
 
     ]
    return(chatsinfo);
}
export default Chatinfo;